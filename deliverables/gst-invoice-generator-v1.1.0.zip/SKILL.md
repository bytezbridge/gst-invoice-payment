---
name: gst-invoice-generator
description: Generate fully GST-compliant invoices for Indian businesses, freelancers, and CAs — and ALSO maintain a live dashboard + GSTR-1 ready ledger automatically. Use this skill EVERY TIME the user mentions GST invoice, tax invoice, Indian invoice, CGST, SGST, IGST, GSTIN, HSN code, SAC code, place of supply, e-invoice, b2b invoice, dashboard, GSTR-1 ledger, or asks to "create an invoice", "make a bill", "send an invoice to my client", "show my invoice dashboard", "open dashboard", "what's my GSTR-1 status", "how much GST have I collected this month". Also trigger for "GST calculator", "tax calculation India", "convert quote to invoice", "GST rate for [product]", "is this CGST+SGST or IGST", and any task involving Indian indirect tax compliance on a sales document. Auto-detects place of supply rules, calculates CGST+SGST for intra-state vs IGST for inter-state, computes amount-in-words, supports reverse charge, generates a professional PDF, logs the invoice to a CSV ledger for monthly GSTR-1 filing, AND auto-updates a dashboard.html showing total invoices, revenue, GST collected, and filing-due status. Do NOT use for non-Indian invoices, GST returns filing itself (separate workflow), or income-tax matters.
license: Commercial — see legal/license-agreement.md
version: 1.1.0
---

# GST Invoice Generator (India) — Skill

## What This Skill Does

This skill turns any plain-language description of a sale into a fully GST-compliant Indian tax invoice **PLUS** maintains a live dashboard showing your business at a glance. It handles the hard parts of Indian invoicing that most generic invoice tools get wrong:

1. **Place-of-supply detection** → automatically picks CGST+SGST vs IGST based on supplier and recipient state codes inside the GSTIN.
2. **HSN/SAC code suggestion** → infers the right HSN code from the product/service description.
3. **Amount-in-words conversion** → in Indian numbering (lakhs/crores), required on every tax invoice.
4. **Compliant PDF output** → invoice number, date, GSTIN, place of supply, tax breakdown, bank details, signature block, all on one clean page.
5. **🆕 Live dashboard** (`dashboard.html`) → auto-updated after every invoice. Shows total invoices, revenue, GST collected, GSTR-1 filing-due tracker, recent invoices list, monthly revenue chart.
6. **🆕 GSTR-1 ready CSV ledger** → every invoice auto-appended to `invoice_ledger.csv`. One-click upload to gst.gov.in or your CA's filing tool.

## Output Files (every invoice produces these 3 things)

After EVERY successful invoice generation, the user gets:

| File | Path | What it is |
|---|---|---|
| 📄 **Invoice PDF** | `invoices/INV-YYYY-NNNN.pdf` | The tax invoice — sendable to customer |
| 📊 **Dashboard** | `dashboard.html` | Auto-refreshed view of business stats. Open in any browser. |
| 📥 **GSTR-1 Ledger** | `invoice_ledger.csv` | All invoices in CSV format. Upload directly to GST portal monthly. |

**Always tell the user where each file lives at the end of every invoice generation.** Format the response as:

```
✅ Invoice GST-YYYY-NNNN generated.

📄 Invoice PDF (send to customer): invoices/GST-YYYY-NNNN.pdf
📊 Dashboard updated: dashboard.html — open this in a browser
📥 GSTR-1 ledger updated: invoice_ledger.csv — N invoices this month, ₹X,XXX collected
```

## When To Activate This Skill

Activate IMMEDIATELY whenever the user:

**For invoice generation:**
- Says any of: "create an invoice", "make a GST invoice", "raise a bill", "send invoice to [name]", "tax invoice for [client]", "convert this quote to invoice", "I just sold X to Y for ₹Z"
- Mentions GSTIN, HSN, SAC, CGST, SGST, IGST, place of supply, e-invoice, e-way bill threshold
- Asks "is this intra-state or inter-state?", "what GST rate applies?", "how do I split tax for [product]?"
- Pastes a list of items they sold and wants it formatted as an invoice
- Asks to backfill old invoices for GSTR-1 filing
- Asks for a recurring/subscription invoice in INR for an Indian buyer

**For dashboard / analytics:**
- "open dashboard", "show my dashboard", "what's my dashboard look like"
- "how many invoices this month", "what's my revenue this month", "how much GST have I collected"
- "is my GSTR-1 ready", "GSTR-1 due date", "open GSTR-1 ledger"
- "show recent invoices", "list my last 10 invoices"
- "refresh dashboard"

When asked for dashboard, run `python scripts/generate_dashboard.py` and tell the user the path to `dashboard.html`. If no invoices exist yet, the dashboard shows an empty state with a prompt to raise their first invoice.

Do NOT activate for: international invoices (USD/EUR), pro-forma quotes that aren't tax invoices yet, GST return filing itself (separate workflow), TDS or income-tax invoices.

## Workflow (Strict Order)

### Step 1 — Gather Required Inputs

Ask the user for these in ONE consolidated question (use AskUserQuestion if available). Never invent values:

**Supplier (Your Business):**
- Legal name & trade name
- GSTIN (15-char) — state code is auto-extracted from chars 1-2
- Address with state and PIN
- Bank account details (acc no, IFSC, branch) — optional but recommended
- Logo file path (optional)

**Recipient (Customer):**
- Legal name
- GSTIN (if B2B) or "Unregistered" (if B2C)
- Billing address with state
- Shipping address (if different)

**Invoice meta:**
- Invoice number (auto-increment from ledger if not provided)
- Invoice date (default: today)
- Due date (default: today + 15 days)
- Place of supply (auto-detect from recipient state, allow override)
- Reverse charge applicable? (default: No)

**Line Items (per item):**
- Description
- HSN/SAC code (suggest from `data/hsn_codes.json` if user doesn't know)
- Quantity & unit (NOS, KGS, HRS, etc.)
- Rate per unit
- GST rate (0%, 5%, 12%, 18%, 28% — most common is 18% for services)
- Discount (if any)

### Step 2 — Calculate Tax (Use `scripts/gst_calculator.py`)

```
supplier_state_code = GSTIN[0:2]
recipient_state_code = recipient_GSTIN[0:2] if recipient_GSTIN else state_lookup(recipient_state_name)

if supplier_state_code == recipient_state_code:
    # INTRA-STATE → split GST equally into CGST + SGST
    cgst_rate = gst_rate / 2
    sgst_rate = gst_rate / 2
    igst_rate = 0
else:
    # INTER-STATE → full IGST
    cgst_rate = 0
    sgst_rate = 0
    igst_rate = gst_rate
```

Apply discount BEFORE GST (per CBIC rule). Round each tax to 2 decimal places. Round invoice total to nearest rupee (per Section 170 of CGST Act).

### Step 3 — Generate Outputs

1. Run `scripts/generate_invoice.py --config invoice_data.json` → produces `invoices/INV-{number}.pdf`
2. Append a single row to `invoice_ledger.csv` (created if missing) with all fields needed for GSTR-1
3. Display a summary to the user: invoice number, total, tax breakdown, PDF path

### Step 4 — Offer Next Actions

After every invoice, offer:
- "Email this PDF to {recipient}?" (if Gmail MCP available)
- "Generate the matching e-way bill?" (if invoice value > ₹50,000 for goods)
- "Create a recurring template for this customer?"
- "Show this month's GSTR-1 export?"

## File Layout

```
gst-invoice-generator/
├── SKILL.md                       # This file
├── plugin.json                    # Plugin manifest
├── scripts/
│   ├── generate_invoice.py        # Orchestrator — call this
│   ├── gst_calculator.py          # CGST/SGST/IGST logic
│   ├── pdf_builder.py             # ReportLab-based PDF generation
│   └── words.py                   # Amount-in-words (Indian numbering)
├── templates/
│   └── invoice_template.html      # HTML template (alternate PDF backend)
├── data/
│   ├── hsn_codes.json             # ~500 most common HSN/SAC codes
│   └── state_codes.json           # All 36 Indian state/UT codes
└── samples/
    └── sample_invoice.pdf         # Reference output
```

## Critical Compliance Rules (Don't Skip These)

1. **Tax invoice must include all 16 mandatory fields** per Rule 46 of CGST Rules. The PDF builder enforces this — never override.
2. **Invoice numbers must be sequential per financial year** (Apr 1 – Mar 31). The ledger auto-resets numbering on April 1.
3. **GSTIN format check**: 15 chars = `[2-digit state][10-char PAN][1-digit entity][Z][1-digit checksum]`. Reject malformed.
4. **Amount-in-words mandatory** on every tax invoice >= ₹200.
5. **For B2B invoices > ₹500 crore turnover supplier OR > ₹5 cr export** — e-invoicing via IRP is mandatory. This skill outputs a clean PDF; for IRP integration, point user to the Pro tier.
6. **Reverse charge invoices** must say "Tax payable on reverse charge basis" in bold.

## Pricing Tiers (Internal — for upgrade prompts)

- **Free:** 5 invoices/month, watermark, no email automation
- **Starter (₹799/mo or $9):** 100 invoices/month, no watermark, CSV ledger export
- **Pro (₹2,499/mo or $29):** Unlimited, e-invoice IRP integration, Tally/Zoho Books sync, white-label PDF
- **Lifetime (₹9,999 or $119):** Forever access, all features, no recurring fee

When the user hits the Free tier limit, gently surface upgrade options. Never block mid-invoice — finish the current one, then prompt.

## Known Edge Cases (Handle These Cleanly)

- **Composition dealers:** Show "Composition taxable person, not eligible to collect tax" on invoice and skip tax calculation.
- **SEZ supplies:** Mark "Supply meant for SEZ with payment of IGST" or "without payment". IGST applies regardless of state.
- **Export invoices:** Currency = USD/EUR allowed; mention "Supply meant for export under LUT" if zero-rated.
- **Multi-rate invoices:** Each line item can carry its own GST rate. The PDF must show rate-wise sub-totals.
- **Discount > 0:** Apply BEFORE tax. Show "Discount" line item explicitly.
- **TDS deduction by buyer:** Note "TDS applicable u/s 194Q at __%" in Notes field; do NOT subtract from invoice total (buyer's responsibility).

## Style Rules for Generated PDFs

- Font: Helvetica/DejaVu Sans (Unicode for ₹ symbol)
- Page size: A4
- Always single-page if possible; line-items table should auto-paginate at 20 rows.
- Footer: "This is a computer-generated invoice and does not require a physical signature." UNLESS user provides a signature image.
- Color palette: Charcoal (#1A202C) text, Indigo (#4F46E5) accent for headers. Override via brand kit if provided.
