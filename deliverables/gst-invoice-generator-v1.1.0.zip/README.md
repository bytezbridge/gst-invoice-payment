# GST Invoice Generator (India) — Claude Plugin

> Raise GST-compliant Indian tax invoices in 30 seconds, inside Claude.
> Auto CGST/SGST/IGST split · HSN suggestions · GSTR-1-ready CSV ledger.

---

## 🎯 Quick Start (3 minutes)

### 1. Install the skill

```bash
# macOS / Linux
mkdir -p ~/.claude/skills/
cp -r gst-invoice-generator ~/.claude/skills/

# Windows (PowerShell)
mkdir $env:USERPROFILE\.claude\skills\
Copy-Item -Recurse gst-invoice-generator $env:USERPROFILE\.claude\skills\
```

### 2. Install Python dependencies

```bash
pip install reportlab Jinja2 --break-system-packages
```

### 3. Restart Claude Code or Cowork

The skill will auto-load. Test by saying:

> *"raise an invoice for Acme Innovations Bengaluru — 60 hrs dev at ₹2500/hr"*

Claude will pick up the skill, ask for missing details (your GSTIN, recipient GSTIN), and generate `invoices/INV-2627-0001.pdf` plus update `invoice_ledger.csv`.

---

## 📁 What's in this package

```
gst-invoice-generator-plugin/
├── SKILL.md                       # Main skill instructions (Claude reads this)
├── plugin.json                    # Plugin manifest with pricing tiers
├── README.md                      # This file
├── scripts/
│   ├── generate_invoice.py        # Orchestrator — entry point
│   ├── gst_calculator.py          # CGST/SGST/IGST math
│   ├── pdf_builder.py             # ReportLab PDF generation
│   └── words.py                   # Indian-numbering amount-in-words
├── templates/
│   └── invoice_template.html      # Jinja2 HTML template (alternate backend)
├── data/
│   ├── hsn_codes.json             # Top ~80 HSN/SAC codes
│   └── state_codes.json           # All 36 Indian state codes
├── samples/
│   └── sample_invoice.json        # Reference input config
├── landing-page.html              # Sales landing page (deploy to Vercel)
├── distribution/
│   ├── gumroad-listing.md         # Gumroad product copy
│   ├── anthropic-marketplace-submission.md
│   └── launch-kit.md              # ProductHunt + Twitter + LinkedIn + Reddit copy
└── (generated) invoices/, invoice_ledger.csv
```

---

## 🛠️ Direct CLI usage (no Claude required)

You can also run this as a standalone Python tool:

```bash
cd gst-invoice-generator-plugin

# Generate from sample
python scripts/generate_invoice.py --config samples/sample_invoice.json

# Custom invoice
python scripts/generate_invoice.py --config my_invoice.json --out invoices/MY-INV.pdf

# Run unit tests
python scripts/gst_calculator.py
python scripts/words.py
```

---

## 💰 Pricing & Licensing (for resale)

This package is licensed for **personal use** in your own workflow.

To **resell** it (Gumroad, your own SaaS, marketplace listing) you need:
- **Commercial license** — ₹4,999 one-time (covers reselling under your own brand)
- **White-label license** — ₹14,999 one-time (covers full rebranding rights)

Buyer of either license keeps 100% of revenue from end-customers. No royalties.

Contact: r.balaganapathi@gmail.com

---

## 🚀 Distribution playbook (summary)

1. **Launch on Gumroad** Day 1 — own the customer, keep 92% margin.
2. **Submit to Anthropic marketplace** Day 7 — once you have 30 testimonials.
3. **Cross-list on IndieHackers, ProductHunt, Reddit, LinkedIn, Twitter** simultaneously Day 1.
4. **Email 20 friendly CAs / accountants** in advance — beta access in exchange for testimonials.
5. **WhatsApp forward-able** message is your secret weapon for the Indian SMB market — see `distribution/launch-kit.md`.

Realistic targets:
- Day 30: ₹1.85L revenue, 80 paying customers
- Month 6: ₹6L MRR if you stack 2-3 more plugins

---

## 🔧 Roadmap / Pro features (build these next)

- [ ] e-Invoice IRP integration (mandatory for ₹5cr+ turnover suppliers)
- [ ] Tally / Zoho Books CSV sync
- [ ] Multi-currency support (USD/EUR/AED export invoices)
- [ ] WhatsApp invoice delivery via WhatsApp Business API
- [ ] Recurring/subscription invoice scheduling
- [ ] e-Way bill generator (for goods > ₹50K)
- [ ] Hindi/Tamil language UI
- [ ] Mobile-friendly PWA wrapper

---

## 📊 Compliance References

This plugin implements:
- **Section 31** of CGST Act, 2017 (tax invoice issuance)
- **Rule 46** of CGST Rules, 2017 (mandatory invoice fields)
- **Section 7-9** of IGST Act, 2017 (place-of-supply rules)
- **Section 170** of CGST Act (rounding off)

Disclaimer: This tool produces compliant invoices but **does not constitute legal or tax advice**. Consult a qualified Chartered Accountant for your specific situation.

---

## 🤝 Support & Contact

- **Email:** r.balaganapathi@gmail.com (24-hour SLA)
- **Bug reports:** Open an issue on GitHub (link to be added)
- **Feature requests:** email or Twitter DM

Built solo · Made in Chennai 🇮🇳 · For India 🇮🇳

---

## License

Personal use: Free.
Commercial use / resale: Requires Commercial or White-label license (see "Pricing & Licensing" above).

© 2026 Balaganapathi R. All rights reserved.
