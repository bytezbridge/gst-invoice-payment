# Software Licence Agreement — GST Invoice Generator

**Version:** 1.0
**Effective:** 25 April 2026
**Licensor:** Balaganapathi R, sole proprietor, Chennai, Tamil Nadu, India

This Licence Agreement ("Agreement") sets out the licence under which the Software is made available. It supplements (and where in conflict, supersedes) the general Terms & Conditions only with respect to licence rights.

---

## 1. Definitions

- **"Software"** means the GST Invoice Generator plugin, source code, documentation, HSN/SAC reference data, PDF templates, and any updates supplied by the Licensor.
- **"Licensee"** / **"You"** means the natural person or legal entity that has paid for the licence tier indicated on the receipt.
- **"Use"** means installing, running, modifying for internal use, and generating invoices using the Software.
- **"Resell"** means making the Software (or any substantial derivative) available to third parties for value, whether for direct purchase, subscription, or as a feature embedded in another product or service offering.

## 2. Licence tiers

The Software is licenced under one of the following tiers, indicated at the time of purchase:

### 2.1 FREE TIER
- **Use:** internal, by 1 person
- **Limit:** 5 invoices / calendar month
- **Modify source:** ✅ allowed for personal use
- **Resell:** ❌ prohibited
- **Sublicense:** ❌ prohibited
- **Watermark on PDF:** YES
- **Term:** indefinite, free, may be discontinued with 30 days' notice

### 2.2 STARTER TIER (₹799 / $9 per month)
- **Use:** internal, by 1 person, 1 business
- **Limit:** 100 invoices / calendar month
- **Modify source:** ✅ allowed for personal/internal use
- **Resell:** ❌ prohibited
- **Sublicense:** ❌ prohibited
- **Watermark on PDF:** none
- **Term:** monthly auto-renewing; cancel any time

### 2.3 PRO TIER (₹2,499 / $29 per month)
- **Use:** internal, by up to 5 named users in 1 business
- **Limit:** unlimited invoices
- **Modify source:** ✅ allowed for personal/internal use
- **Resell:** ❌ prohibited
- **Sublicense:** ❌ prohibited (note: a CA may use the Pro tier to issue invoices for their own clients — that is permitted "use of the Service for your own clients" and not "reselling the Software")
- **Term:** monthly auto-renewing; cancel any time

### 2.4 LIFETIME TIER (₹9,999 / $119 one-time)
- **Use:** internal, by up to 5 named users in 1 business
- **Limit:** unlimited invoices
- **Modify source:** ✅ allowed for personal/internal use
- **Resell:** ❌ prohibited
- **Sublicense:** ❌ prohibited
- **Term:** perpetual, includes all future updates while the Software exists
- **Limit:** offered only to first 100 buyers — once filled, replaced by Pro tier

### 2.5 COMMERCIAL LICENCE (₹4,999 one-time, by invoice)
A separate licence allowing you to:
- ✅ Resell the Software under your own brand to your own customers
- ✅ Embed the Software inside a product you sell (SaaS, app, plugin, etc.)
- ✅ Bundle with consulting / implementation services
- ❌ Sublicense to other resellers
- ❌ Distribute the source code publicly
- ❌ Remove the "Powered by GST Invoice Generator" attribution

A signed Commercial Licence Agreement is required. Email us for the signed PDF.

### 2.6 WHITE-LABEL LICENCE (₹14,999 one-time, by invoice)
Everything in the Commercial Licence, plus:
- ✅ Full rebranding (remove all attribution to us)
- ✅ Resell as your own product without disclosing the underlying engine
- ✅ Modify, repackage, and redistribute the source code as part of your product
- ❌ Sublicense or grant white-label rights to your downstream customers
- ❌ Open-source the code

A signed White-Label Licence Agreement is required.

### 2.7 ENTERPRISE LICENCE (custom, by invoice)
For organisations needing 50+ users, on-premise deployment, custom SLAs, dedicated support, or compliance audits. Contact us for a quote.

## 3. Restrictions (apply to all tiers below the Commercial Licence)

You agree NOT to:
1. Sell, sublicence, lease, rent, or distribute the Software for value
2. Make the Software available to third parties via SaaS, ASP, hosting, or any similar arrangement
3. Use the Software to provide invoicing-as-a-service to others as a paid service (for clarity: a freelancer using the Pro tier to invoice their own design clients is fine; a CA using the Pro tier to invoice clients on behalf of those clients is fine; reselling access to the plugin to other businesses is NOT fine)
4. Reverse-engineer, decompile, or disassemble any closed-source / pre-compiled component
5. Remove or alter copyright notices, attributions, licence text, or proprietary markings
6. Use the Software in any unlawful manner, including for tax fraud or evasion

## 4. Updates

Active subscriptions and Lifetime tier licensees are entitled to all updates released during their term. Free-tier users get bug-fix updates; new features may be limited to paid tiers.

We may release updates with reasonable notice. Updates may modify functionality. If a major update materially reduces the value of the Lifetime tier, you may request a pro-rated refund within 30 days of the update.

## 5. Source code custody

If your tier includes source-code access:
- Code is delivered as a `.zip` package via a one-time download link valid 30 days
- Re-downloads after 30 days require email request
- Source code remains our IP; your licence is to USE the code per the tier above, not to own it
- Modifications you make for internal use are yours; you may not distribute the modified Software publicly

## 6. Trademark

We grant you a non-transferable, royalty-free right to use the words "GST Invoice Generator" solely to describe your use of the Software. You do **not** receive rights to:
- Our logo or wordmark in stylised form
- The "Claude" or "Anthropic" trademarks (those belong to Anthropic, PBC)

White-Label licensees waive all rights to use our marks (which is the point — they brand it as their own).

## 7. Termination

This licence terminates automatically on:
- Non-payment (for paid recurring tiers, after a 7-day grace period)
- Material breach of any restriction in clause 3
- Refund within the 30-day window (Lifetime) or end of cycle (recurring)

Upon termination:
- You must uninstall the Software and destroy all copies (including modified versions, except for tax-record reasons)
- Lifetime, Commercial, and White-Label tier terminations are subject to the survival clause in our Terms & Conditions

## 8. Warranty disclaimer & liability

Refer to the Terms & Conditions clauses 9 (Warranty) and 10 (Limitation of Liability). The same caps and disclaimers apply here. The total cap for Commercial / White-Label / Enterprise tiers is the higher of (a) the licence fee paid in the past 12 months and (b) ₹50,000.

## 9. Audit (Commercial / White-Label / Enterprise only)

For tiers that allow resale, we reserve the right to audit licensee usage upon **15 days' written notice**, no more than once per year. Audits cover only the scope of the licence (number of users, invoices generated, downstream customers). Confidentiality applies; we sign an NDA before any audit.

## 10. Governing law & disputes

Governed by Indian law. Disputes follow the same arbitration clause as the Terms & Conditions (Chennai seat, sole arbitrator, English language).

---

*To purchase Commercial, White-Label, or Enterprise licences, email r.balaganapathi@gmail.com with the subject "Commercial Licence Inquiry" — we typically reply within 24 hours with a signed PDF and Razorpay payment link.*
