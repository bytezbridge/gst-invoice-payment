"""
GST Calculator — handles CGST/SGST/IGST split per Indian Place-of-Supply rules.

Reference: Section 7-9 of IGST Act, 2017 + Rule 46 of CGST Rules, 2017.

Author: Balaganapathi R
License: Commercial
"""

from __future__ import annotations
from dataclasses import dataclass, field
from decimal import Decimal, ROUND_HALF_UP
from typing import List, Optional


# ---------- Helpers ----------

def _q2(value) -> Decimal:
    """Quantize to 2 decimal places, banker-friendly half-up rounding."""
    return Decimal(str(value)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)


def validate_gstin(gstin: str) -> bool:
    """Basic structural validation. Format: 2-digit state + 10-char PAN + 1 entity + Z + 1 checksum."""
    if not gstin or len(gstin) != 15:
        return False
    if not gstin[0:2].isdigit():
        return False
    if gstin[13] != "Z":
        return False
    return True


def state_code_from_gstin(gstin: str) -> str:
    if not validate_gstin(gstin):
        raise ValueError(f"Invalid GSTIN: {gstin}")
    return gstin[0:2]


# ---------- Data classes ----------

@dataclass
class LineItem:
    description: str
    hsn_sac: str
    quantity: Decimal
    unit: str  # NOS, KGS, HRS, etc.
    rate: Decimal  # rate per unit, before tax
    gst_rate_pct: Decimal  # 0, 5, 12, 18, 28
    discount_pct: Decimal = Decimal("0")

    # Computed fields (populated by calculator)
    taxable_value: Decimal = field(default=Decimal("0"))
    cgst_amount: Decimal = field(default=Decimal("0"))
    sgst_amount: Decimal = field(default=Decimal("0"))
    igst_amount: Decimal = field(default=Decimal("0"))
    total_with_tax: Decimal = field(default=Decimal("0"))


@dataclass
class InvoiceTotals:
    sub_total: Decimal
    total_discount: Decimal
    taxable_value: Decimal
    total_cgst: Decimal
    total_sgst: Decimal
    total_igst: Decimal
    grand_total: Decimal
    round_off: Decimal
    grand_total_rounded: Decimal


# ---------- Core ----------

def calculate_line_item(
    item: LineItem,
    is_intra_state: bool,
) -> LineItem:
    """Compute taxable value + CGST/SGST or IGST per line."""

    gross = item.quantity * item.rate
    discount_amt = (gross * item.discount_pct) / Decimal("100")
    taxable = gross - discount_amt

    item.taxable_value = _q2(taxable)

    if is_intra_state:
        half_rate = item.gst_rate_pct / Decimal("2")
        item.cgst_amount = _q2((taxable * half_rate) / Decimal("100"))
        item.sgst_amount = _q2((taxable * half_rate) / Decimal("100"))
        item.igst_amount = _q2(0)
    else:
        item.cgst_amount = _q2(0)
        item.sgst_amount = _q2(0)
        item.igst_amount = _q2((taxable * item.gst_rate_pct) / Decimal("100"))

    item.total_with_tax = _q2(
        item.taxable_value + item.cgst_amount + item.sgst_amount + item.igst_amount
    )
    return item


def calculate_invoice(
    line_items: List[LineItem],
    supplier_gstin: str,
    recipient_state_code: str,
) -> tuple[List[LineItem], InvoiceTotals]:
    """
    Calculate the complete invoice.

    Returns the list of computed line items and the totals block.
    Place-of-supply: if supplier state == recipient state -> intra-state (CGST+SGST).
    Otherwise -> inter-state (IGST).
    """

    supplier_state = state_code_from_gstin(supplier_gstin)
    is_intra_state = supplier_state == recipient_state_code

    sub_total = Decimal("0")
    total_discount = Decimal("0")
    taxable_value = Decimal("0")
    total_cgst = Decimal("0")
    total_sgst = Decimal("0")
    total_igst = Decimal("0")

    for item in line_items:
        gross = item.quantity * item.rate
        discount_amt = (gross * item.discount_pct) / Decimal("100")
        sub_total += gross
        total_discount += discount_amt
        calculate_line_item(item, is_intra_state)
        taxable_value += item.taxable_value
        total_cgst += item.cgst_amount
        total_sgst += item.sgst_amount
        total_igst += item.igst_amount

    grand_total = taxable_value + total_cgst + total_sgst + total_igst
    grand_total_rounded = Decimal(int(grand_total + Decimal("0.5")))
    round_off = grand_total_rounded - grand_total

    totals = InvoiceTotals(
        sub_total=_q2(sub_total),
        total_discount=_q2(total_discount),
        taxable_value=_q2(taxable_value),
        total_cgst=_q2(total_cgst),
        total_sgst=_q2(total_sgst),
        total_igst=_q2(total_igst),
        grand_total=_q2(grand_total),
        round_off=_q2(round_off),
        grand_total_rounded=_q2(grand_total_rounded),
    )

    return line_items, totals


# ---------- Self-test ----------

if __name__ == "__main__":
    # Quick smoke test: Tamil Nadu (33) supplier selling consulting service to:
    #   (a) another TN client -> intra-state -> CGST 9% + SGST 9%
    #   (b) Karnataka (29) client -> inter-state -> IGST 18%

    items_intra = [
        LineItem(
            description="Web development consulting",
            hsn_sac="998314",
            quantity=Decimal("10"),
            unit="HRS",
            rate=Decimal("2500"),
            gst_rate_pct=Decimal("18"),
        )
    ]
    items_inter = [
        LineItem(
            description="Web development consulting",
            hsn_sac="998314",
            quantity=Decimal("10"),
            unit="HRS",
            rate=Decimal("2500"),
            gst_rate_pct=Decimal("18"),
        )
    ]

    supplier = "33ABCDE1234F1Z5"  # TN GSTIN (state code 33)

    _, t1 = calculate_invoice(items_intra, supplier, recipient_state_code="33")
    _, t2 = calculate_invoice(items_inter, supplier, recipient_state_code="29")

    print("=== Intra-state (TN -> TN) ===")
    print(f"Taxable: ₹{t1.taxable_value} | CGST: ₹{t1.total_cgst} | SGST: ₹{t1.total_sgst} | IGST: ₹{t1.total_igst}")
    print(f"Grand Total: ₹{t1.grand_total_rounded}")

    print("\n=== Inter-state (TN -> KA) ===")
    print(f"Taxable: ₹{t2.taxable_value} | CGST: ₹{t2.total_cgst} | SGST: ₹{t2.total_sgst} | IGST: ₹{t2.total_igst}")
    print(f"Grand Total: ₹{t2.grand_total_rounded}")

    assert t1.total_cgst == Decimal("2250.00"), "Intra-state CGST should be 2250"
    assert t1.total_sgst == Decimal("2250.00"), "Intra-state SGST should be 2250"
    assert t1.total_igst == Decimal("0.00"), "Intra-state IGST should be 0"
    assert t2.total_igst == Decimal("4500.00"), "Inter-state IGST should be 4500"
    assert t2.total_cgst == Decimal("0.00"), "Inter-state CGST should be 0"
    print("\nAll assertions passed.")
