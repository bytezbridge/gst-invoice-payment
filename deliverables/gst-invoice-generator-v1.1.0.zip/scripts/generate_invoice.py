"""
Orchestrator — reads invoice config (JSON), generates PDF + appends to ledger.

Usage:
    python generate_invoice.py --config sample_invoice.json
    python generate_invoice.py --config sample_invoice.json --out invoices/INV-001.pdf
"""

from __future__ import annotations
import argparse
import csv
import json
import sys
from datetime import datetime
from decimal import Decimal
from pathlib import Path

# Allow running as a script
sys.path.insert(0, str(Path(__file__).parent))

from gst_calculator import LineItem, calculate_invoice, state_code_from_gstin, validate_gstin
from pdf_builder import build_invoice_pdf


LEDGER_FILE = "invoice_ledger.csv"
LEDGER_HEADERS = [
    "invoice_number", "invoice_date", "customer_name", "supplier_gstin", "recipient_name",
    "recipient_gstin", "recipient_state_code", "place_of_supply", "tax_type",
    "taxable_value", "cgst", "sgst", "igst", "grand_total", "pdf_path"
]


def _load_config(path: str) -> dict:
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def _next_invoice_number(ledger_path: Path, prefix: str = "INV") -> str:
    """Auto-increment from ledger. Resets on April 1 (Indian financial year)."""
    today = datetime.now()
    fy_start = today.year if today.month >= 4 else today.year - 1
    fy_label = f"{str(fy_start)[-2:]}{str(fy_start + 1)[-2:]}"

    if not ledger_path.exists():
        return f"{prefix}/{fy_label}/0001"

    counter = 0
    with open(ledger_path, "r", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for row in reader:
            if f"/{fy_label}/" in row.get("invoice_number", ""):
                counter += 1
    return f"{prefix}/{fy_label}/{counter + 1:04d}"


def _append_to_ledger(ledger_path: Path, row: dict):
    """Append a row to the ledger. If file exists with old schema (missing
    customer_name/tax_type), use only the existing headers (extras dropped).
    If file is new, use the full new schema."""
    is_new = not ledger_path.exists()
    if is_new:
        fieldnames = LEDGER_HEADERS
    else:
        # Read existing header to know which columns to write
        with open(ledger_path, "r", encoding="utf-8") as f:
            existing = f.readline().strip().split(",")
        fieldnames = existing if existing else LEDGER_HEADERS

    with open(ledger_path, "a", encoding="utf-8", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames, extrasaction="ignore")
        if is_new:
            writer.writeheader()
        writer.writerow(row)


def _to_decimal(x) -> Decimal:
    return Decimal(str(x))


def generate(config: dict, output_pdf: str = None, ledger_path: str = LEDGER_FILE) -> dict:
    supplier = config["supplier"]
    recipient = config["recipient"]
    invoice_meta = dict(config.get("invoice_meta", {}))

    # Validate
    if not validate_gstin(supplier["gstin"]):
        raise ValueError(f"Supplier GSTIN invalid: {supplier['gstin']}")

    # Auto fields
    ledger_p = Path(ledger_path)
    if not invoice_meta.get("invoice_number"):
        invoice_meta["invoice_number"] = _next_invoice_number(ledger_p)
    if not invoice_meta.get("invoice_date"):
        invoice_meta["invoice_date"] = datetime.now().strftime("%d-%b-%Y")

    # Determine recipient state
    recipient_state_code = recipient.get("state_code")
    if recipient.get("gstin") and recipient["gstin"].lower() != "unregistered":
        recipient_state_code = state_code_from_gstin(recipient["gstin"])
    if not recipient_state_code:
        raise ValueError("Recipient state_code required when GSTIN unavailable")
    recipient["state_code"] = recipient_state_code

    supplier["state_code"] = state_code_from_gstin(supplier["gstin"])
    if not invoice_meta.get("place_of_supply"):
        invoice_meta["place_of_supply"] = f"{recipient.get('state', '')} ({recipient_state_code})"

    is_intra_state = supplier["state_code"] == recipient_state_code

    # Build line items
    line_items = []
    for li in config["line_items"]:
        line_items.append(LineItem(
            description=li["description"],
            hsn_sac=str(li.get("hsn_sac", "")),
            quantity=_to_decimal(li["quantity"]),
            unit=li.get("unit", "NOS"),
            rate=_to_decimal(li["rate"]),
            gst_rate_pct=_to_decimal(li["gst_rate_pct"]),
            discount_pct=_to_decimal(li.get("discount_pct", 0)),
        ))

    line_items, totals = calculate_invoice(
        line_items,
        supplier_gstin=supplier["gstin"],
        recipient_state_code=recipient_state_code,
    )

    # Output path
    if not output_pdf:
        safe_num = invoice_meta["invoice_number"].replace("/", "-")
        output_pdf = f"invoices/{safe_num}.pdf"

    pdf_path = build_invoice_pdf(
        output_path=output_pdf,
        supplier=supplier,
        recipient=recipient,
        invoice_meta=invoice_meta,
        line_items=line_items,
        totals=totals,
        is_intra_state=is_intra_state,
        notes=config.get("notes", ""),
    )

    # Append ledger
    tax_type = "CGST+SGST" if is_intra_state else "IGST"
    _append_to_ledger(ledger_p, {
        "invoice_number": invoice_meta["invoice_number"],
        "invoice_date": invoice_meta["invoice_date"],
        "customer_name": recipient["legal_name"],
        "supplier_gstin": supplier["gstin"],
        "recipient_name": recipient["legal_name"],
        "recipient_gstin": recipient.get("gstin", "Unregistered"),
        "recipient_state_code": recipient_state_code,
        "place_of_supply": invoice_meta["place_of_supply"],
        "tax_type": tax_type,
        "taxable_value": str(totals.taxable_value),
        "cgst": str(totals.total_cgst),
        "sgst": str(totals.total_sgst),
        "igst": str(totals.total_igst),
        "grand_total": str(totals.grand_total_rounded),
        "pdf_path": pdf_path,
    })

    # Auto-update dashboard
    dashboard_path = None
    try:
        from generate_dashboard import generate as gen_dashboard
        dash_result = gen_dashboard(ledger_path=ledger_p)
        dashboard_path = dash_result["dashboard_path"]
    except Exception as e:
        # Dashboard generation is best-effort; don't fail the whole invoice
        print(f"⚠️  Dashboard auto-update failed: {e}", file=__import__("sys").stderr)

    return {
        "invoice_number": invoice_meta["invoice_number"],
        "pdf_path": pdf_path,
        "ledger_path": str(ledger_p),
        "dashboard_path": dashboard_path,
        "totals": {
            "taxable_value": str(totals.taxable_value),
            "cgst": str(totals.total_cgst),
            "sgst": str(totals.total_sgst),
            "igst": str(totals.total_igst),
            "grand_total": str(totals.grand_total_rounded),
        },
        "is_intra_state": is_intra_state,
        "tax_type": tax_type,
        "next_actions": [
            f"📄 Open the invoice PDF: {pdf_path}",
            f"📊 View your dashboard: {dashboard_path or 'dashboard.html (run generate_dashboard.py)'}",
            f"📥 GSTR-1 ledger updated: {ledger_p}",
            "💡 Tip: forward this PDF to your customer via email or WhatsApp",
        ],
    }


def main():
    p = argparse.ArgumentParser(description="Generate a GST-compliant tax invoice")
    p.add_argument("--config", required=True, help="Path to invoice JSON config")
    p.add_argument("--out", help="Output PDF path (optional)")
    p.add_argument("--ledger", default=LEDGER_FILE, help="Path to ledger CSV")
    args = p.parse_args()

    cfg = _load_config(args.config)
    result = generate(cfg, output_pdf=args.out, ledger_path=args.ledger)
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
