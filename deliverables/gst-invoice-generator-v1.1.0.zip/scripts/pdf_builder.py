"""
PDF builder using ReportLab. Pure Python, no external system dependencies.

Install:  pip install reportlab --break-system-packages
"""

from __future__ import annotations
from decimal import Decimal
from pathlib import Path
from typing import List, Dict, Any

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import mm
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, KeepTogether
)

from words import amount_to_words


INDIGO = colors.HexColor("#4F46E5")
CHARCOAL = colors.HexColor("#1A202C")
LIGHT_GREY = colors.HexColor("#F3F4F6")
BORDER = colors.HexColor("#E5E7EB")


def _styles():
    base = getSampleStyleSheet()
    s = {
        "title": ParagraphStyle("title", parent=base["Heading1"],
                                fontName="Helvetica-Bold", fontSize=22,
                                textColor=INDIGO, spaceAfter=2),
        "subtitle": ParagraphStyle("subtitle", parent=base["Normal"],
                                   fontName="Helvetica", fontSize=9,
                                   textColor=CHARCOAL, leading=11),
        "h2": ParagraphStyle("h2", parent=base["Heading2"],
                             fontName="Helvetica-Bold", fontSize=11,
                             textColor=INDIGO, spaceAfter=4),
        "label": ParagraphStyle("label", parent=base["Normal"],
                                fontName="Helvetica-Bold", fontSize=8,
                                textColor=CHARCOAL),
        "body": ParagraphStyle("body", parent=base["Normal"],
                               fontName="Helvetica", fontSize=9,
                               textColor=CHARCOAL, leading=12),
        "small": ParagraphStyle("small", parent=base["Normal"],
                                fontName="Helvetica", fontSize=8,
                                textColor=colors.grey, leading=10),
    }
    return s


def build_invoice_pdf(
    output_path: str,
    supplier: Dict[str, Any],
    recipient: Dict[str, Any],
    invoice_meta: Dict[str, Any],
    line_items: List[Any],
    totals: Any,
    is_intra_state: bool,
    notes: str = "",
):
    """
    Build a one-page A4 GST-compliant tax invoice.

    line_items must be the LineItem dataclass objects from gst_calculator.
    totals is the InvoiceTotals dataclass.
    """
    output_path = Path(output_path)
    output_path.parent.mkdir(parents=True, exist_ok=True)

    s = _styles()
    doc = SimpleDocTemplate(
        str(output_path),
        pagesize=A4,
        leftMargin=15 * mm, rightMargin=15 * mm,
        topMargin=15 * mm, bottomMargin=15 * mm,
        title=f"Tax Invoice {invoice_meta.get('invoice_number', '')}",
    )
    story = []

    # ---------- Header ----------
    header_data = [
        [
            Paragraph(f"<b>{supplier.get('legal_name', '')}</b><br/>"
                      f"<font size=8>{supplier.get('address', '')}<br/>"
                      f"GSTIN: {supplier.get('gstin', '')}<br/>"
                      f"State: {supplier.get('state', '')} ({supplier.get('state_code', '')})<br/>"
                      f"{supplier.get('email', '')} | {supplier.get('phone', '')}</font>",
                      s["body"]),
            Paragraph("TAX INVOICE", s["title"]),
        ]
    ]
    header_tbl = Table(header_data, colWidths=[110 * mm, 70 * mm])
    header_tbl.setStyle(TableStyle([
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("ALIGN", (1, 0), (1, 0), "RIGHT"),
    ]))
    story.append(header_tbl)
    story.append(Spacer(1, 6))

    # Thin divider
    div = Table([[" "]], colWidths=[180 * mm], rowHeights=[1])
    div.setStyle(TableStyle([("LINEABOVE", (0, 0), (-1, -1), 1, INDIGO)]))
    story.append(div)
    story.append(Spacer(1, 8))

    # ---------- Invoice meta + Recipient ----------
    meta_block = Paragraph(
        f"<b>Invoice No:</b> {invoice_meta.get('invoice_number', '')}<br/>"
        f"<b>Invoice Date:</b> {invoice_meta.get('invoice_date', '')}<br/>"
        f"<b>Due Date:</b> {invoice_meta.get('due_date', '')}<br/>"
        f"<b>Place of Supply:</b> {invoice_meta.get('place_of_supply', '')}<br/>"
        f"<b>Reverse Charge:</b> {'Yes' if invoice_meta.get('reverse_charge') else 'No'}",
        s["body"],
    )

    recipient_block = Paragraph(
        f"<b>Bill To:</b><br/>"
        f"<b>{recipient.get('legal_name', '')}</b><br/>"
        f"{recipient.get('address', '')}<br/>"
        f"GSTIN: {recipient.get('gstin', 'Unregistered')}<br/>"
        f"State: {recipient.get('state', '')} ({recipient.get('state_code', '')})",
        s["body"],
    )

    meta_tbl = Table([[recipient_block, meta_block]], colWidths=[110 * mm, 70 * mm])
    meta_tbl.setStyle(TableStyle([
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("BOX", (0, 0), (-1, -1), 0.5, BORDER),
        ("LEFTPADDING", (0, 0), (-1, -1), 8),
        ("RIGHTPADDING", (0, 0), (-1, -1), 8),
        ("TOPPADDING", (0, 0), (-1, -1), 8),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 8),
        ("LINEAFTER", (0, 0), (0, 0), 0.5, BORDER),
    ]))
    story.append(meta_tbl)
    story.append(Spacer(1, 10))

    # ---------- Line items table ----------
    if is_intra_state:
        head = ["#", "Description", "HSN/SAC", "Qty", "Rate", "Taxable",
                "CGST %", "CGST", "SGST %", "SGST", "Total"]
    else:
        head = ["#", "Description", "HSN/SAC", "Qty", "Rate", "Taxable",
                "IGST %", "IGST", "Total"]

    rows = [head]
    for idx, item in enumerate(line_items, 1):
        if is_intra_state:
            half = item.gst_rate_pct / Decimal("2")
            rows.append([
                str(idx),
                item.description,
                item.hsn_sac,
                f"{item.quantity} {item.unit}",
                f"₹{item.rate}",
                f"₹{item.taxable_value}",
                f"{half}%",
                f"₹{item.cgst_amount}",
                f"{half}%",
                f"₹{item.sgst_amount}",
                f"₹{item.total_with_tax}",
            ])
        else:
            rows.append([
                str(idx),
                item.description,
                item.hsn_sac,
                f"{item.quantity} {item.unit}",
                f"₹{item.rate}",
                f"₹{item.taxable_value}",
                f"{item.gst_rate_pct}%",
                f"₹{item.igst_amount}",
                f"₹{item.total_with_tax}",
            ])

    if is_intra_state:
        col_widths = [10*mm, 38*mm, 18*mm, 14*mm, 16*mm, 18*mm, 12*mm, 14*mm, 12*mm, 14*mm, 16*mm]
    else:
        col_widths = [10*mm, 50*mm, 22*mm, 16*mm, 18*mm, 22*mm, 14*mm, 16*mm, 22*mm]

    tbl = Table(rows, colWidths=col_widths, repeatRows=1)
    tbl.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), INDIGO),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
        ("FONTSIZE", (0, 0), (-1, 0), 8),
        ("FONTSIZE", (0, 1), (-1, -1), 8),
        ("ALIGN", (3, 1), (-1, -1), "RIGHT"),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("ROWBACKGROUNDS", (0, 1), (-1, -1), [colors.white, LIGHT_GREY]),
        ("BOX", (0, 0), (-1, -1), 0.5, BORDER),
        ("INNERGRID", (0, 0), (-1, -1), 0.25, BORDER),
        ("TOPPADDING", (0, 0), (-1, -1), 4),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
    ]))
    story.append(tbl)
    story.append(Spacer(1, 8))

    # ---------- Totals + amount in words ----------
    totals_rows = [
        ["Sub-total", f"₹{totals.sub_total}"],
        ["Discount", f"₹{totals.total_discount}"],
        ["Taxable Value", f"₹{totals.taxable_value}"],
    ]
    if is_intra_state:
        totals_rows += [
            ["Total CGST", f"₹{totals.total_cgst}"],
            ["Total SGST", f"₹{totals.total_sgst}"],
        ]
    else:
        totals_rows.append(["Total IGST", f"₹{totals.total_igst}"])
    totals_rows += [
        ["Round Off", f"₹{totals.round_off}"],
        ["Grand Total", f"₹{totals.grand_total_rounded}"],
    ]

    totals_tbl = Table(totals_rows, colWidths=[40*mm, 30*mm])
    totals_tbl.setStyle(TableStyle([
        ("FONTNAME", (0, -1), (-1, -1), "Helvetica-Bold"),
        ("BACKGROUND", (0, -1), (-1, -1), INDIGO),
        ("TEXTCOLOR", (0, -1), (-1, -1), colors.white),
        ("ALIGN", (1, 0), (1, -1), "RIGHT"),
        ("FONTSIZE", (0, 0), (-1, -1), 9),
        ("BOX", (0, 0), (-1, -1), 0.5, BORDER),
        ("INNERGRID", (0, 0), (-1, -1), 0.25, BORDER),
        ("LEFTPADDING", (0, 0), (-1, -1), 6),
        ("RIGHTPADDING", (0, 0), (-1, -1), 6),
        ("TOPPADDING", (0, 0), (-1, -1), 4),
        ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
    ]))

    words_block = Paragraph(
        f"<b>Amount in words:</b><br/>"
        f"<i>{amount_to_words(totals.grand_total_rounded)}</i>",
        s["body"],
    )

    bottom_tbl = Table([[words_block, totals_tbl]], colWidths=[110*mm, 70*mm])
    bottom_tbl.setStyle(TableStyle([("VALIGN", (0, 0), (-1, -1), "TOP")]))
    story.append(bottom_tbl)
    story.append(Spacer(1, 14))

    # ---------- Bank + Notes + Signature ----------
    bank = supplier.get("bank", {})
    bank_block = Paragraph(
        f"<b>Bank Details</b><br/>"
        f"Account Name: {bank.get('account_name', supplier.get('legal_name',''))}<br/>"
        f"Account Number: {bank.get('account_number', '')}<br/>"
        f"IFSC: {bank.get('ifsc', '')}<br/>"
        f"Branch: {bank.get('branch', '')}",
        s["body"],
    ) if bank else Paragraph(" ", s["body"])

    sig_block = Paragraph(
        f"<br/><br/><br/><b>For {supplier.get('legal_name', '')}</b><br/>"
        f"<font size=8>Authorised Signatory</font>",
        s["body"],
    )

    sig_tbl = Table([[bank_block, sig_block]], colWidths=[110*mm, 70*mm])
    sig_tbl.setStyle(TableStyle([
        ("VALIGN", (0, 0), (-1, -1), "TOP"),
        ("ALIGN", (1, 0), (1, 0), "RIGHT"),
    ]))
    story.append(sig_tbl)

    if invoice_meta.get("reverse_charge"):
        story.append(Spacer(1, 8))
        story.append(Paragraph(
            "<b>Tax payable on reverse charge basis</b>", s["label"]
        ))

    if notes:
        story.append(Spacer(1, 8))
        story.append(Paragraph(f"<b>Notes:</b> {notes}", s["small"]))

    story.append(Spacer(1, 12))
    story.append(Paragraph(
        "This is a computer-generated invoice issued under the GST Act, 2017. "
        "Generated by GST Invoice Generator Plugin.",
        s["small"]
    ))

    doc.build(story)
    return str(output_path)
