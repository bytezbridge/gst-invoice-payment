#!/usr/bin/env python3
"""
Dashboard generator for GST Invoice Generator.

Reads the invoice_ledger.csv and produces a beautiful dashboard.html
showing total invoices, revenue, GST collected, GSTR-1 status, and
recent invoice list.

Usage:
    python scripts/generate_dashboard.py
    python scripts/generate_dashboard.py --ledger /path/to/ledger.csv --out dashboard.html
"""

import argparse
import csv
import json
import os
import sys
from collections import defaultdict
from datetime import datetime, date
from decimal import Decimal
from pathlib import Path

# ---------- Config ----------
DEFAULT_LEDGER = Path(__file__).parent.parent / "invoice_ledger.csv"
DEFAULT_OUTPUT = Path(__file__).parent.parent / "dashboard.html"


def _to_decimal(value):
    if value is None or value == "":
        return Decimal("0.00")
    return Decimal(str(value).replace(",", ""))


def _format_inr(amount):
    """Format any numeric value (int, float, Decimal, str) as Indian-style ₹1,23,456.00"""
    if amount is None or amount == "":
        amount = Decimal("0")
    if isinstance(amount, str):
        try:
            amount = Decimal(amount.replace(",", "").replace("₹", "").strip())
        except Exception:
            amount = Decimal("0")
    elif not isinstance(amount, Decimal):
        amount = Decimal(str(amount))
    s = f"{amount:.2f}"
    int_part, dec_part = s.split(".")
    if int_part.startswith("-"):
        sign = "-"
        int_part = int_part[1:]
    else:
        sign = ""
    if len(int_part) <= 3:
        return f"{sign}₹{int_part}.{dec_part}"
    head = int_part[:-3]
    tail = int_part[-3:]
    chunks = []
    while len(head) > 2:
        chunks.insert(0, head[-2:])
        head = head[:-2]
    if head:
        chunks.insert(0, head)
    return f"{sign}₹{','.join(chunks)},{tail}.{dec_part}"


def _gstr1_due_date(month_year):
    """GSTR-1 due date is the 11th of the following month."""
    try:
        dt = datetime.strptime(f"01 {month_year}", "%d %B %Y")
    except ValueError:
        return None
    nxt_month = dt.month + 1
    nxt_year = dt.year
    if nxt_month > 12:
        nxt_month = 1
        nxt_year += 1
    return date(nxt_year, nxt_month, 11)


def load_invoices(ledger_path):
    """Load all invoice rows from the ledger CSV."""
    if not Path(ledger_path).exists():
        return []
    with open(ledger_path, encoding="utf-8") as f:
        reader = csv.DictReader(f)
        return list(reader)


def compute_stats(invoices):
    """Compute aggregate stats from invoice list."""
    if not invoices:
        return {
            "total_count": 0,
            "this_month_count": 0,
            "total_revenue": Decimal("0"),
            "this_month_revenue": Decimal("0"),
            "total_gst": Decimal("0"),
            "this_month_gst": Decimal("0"),
            "by_month": {},
            "current_month_label": datetime.now().strftime("%B %Y"),
            "gstr1_due": _gstr1_due_date(datetime.now().strftime("%B %Y")),
        }

    by_month = defaultdict(lambda: {"count": 0, "revenue": Decimal("0"), "tax": Decimal("0"), "rows": []})
    total_count = 0
    total_revenue = Decimal("0")
    total_gst = Decimal("0")

    current_month_label = datetime.now().strftime("%B %Y")
    current_month_count = 0
    current_month_revenue = Decimal("0")
    current_month_gst = Decimal("0")

    for inv in invoices:
        date_str = inv.get("invoice_date") or inv.get("date") or ""
        try:
            dt = datetime.strptime(date_str, "%Y-%m-%d")
        except (ValueError, TypeError):
            try:
                dt = datetime.strptime(date_str, "%d %b %Y")
            except (ValueError, TypeError):
                dt = datetime.now()
        month_label = dt.strftime("%B %Y")

        taxable = _to_decimal(inv.get("taxable_value") or inv.get("amount") or "0")
        tax = _to_decimal(inv.get("cgst") or "0") + _to_decimal(inv.get("sgst") or "0") + _to_decimal(inv.get("igst") or "0")
        grand = _to_decimal(inv.get("grand_total") or inv.get("total") or "0")
        if grand == 0:
            grand = taxable + tax

        by_month[month_label]["count"] += 1
        by_month[month_label]["revenue"] += grand
        by_month[month_label]["tax"] += tax
        by_month[month_label]["rows"].append(inv)

        total_count += 1
        total_revenue += grand
        total_gst += tax

        if month_label == current_month_label:
            current_month_count += 1
            current_month_revenue += grand
            current_month_gst += tax

    return {
        "total_count": total_count,
        "this_month_count": current_month_count,
        "total_revenue": total_revenue,
        "this_month_revenue": current_month_revenue,
        "total_gst": total_gst,
        "this_month_gst": current_month_gst,
        "by_month": {k: v for k, v in sorted(by_month.items(), key=lambda x: datetime.strptime(x[0], "%B %Y"), reverse=True)},
        "current_month_label": current_month_label,
        "gstr1_due": _gstr1_due_date(current_month_label),
    }


def render_dashboard(stats, invoices, output_path):
    """Render dashboard.html using stats."""
    template_path = Path(__file__).parent.parent / "templates" / "dashboard_template.html"
    if not template_path.exists():
        # Fallback inline template (if templates/ wasn't shipped)
        return _render_inline(stats, invoices, output_path)

    try:
        from jinja2 import Template
    except ImportError:
        return _render_inline(stats, invoices, output_path)

    with open(template_path, encoding="utf-8") as f:
        template = Template(f.read())

    # Get the 10 most recent invoices
    recent = sorted(
        invoices,
        key=lambda i: i.get("invoice_date") or i.get("date") or "",
        reverse=True,
    )[:10]

    # Build month-by-month chart data
    chart_months = list(stats["by_month"].keys())[:6][::-1]
    chart_revenue = [float(stats["by_month"][m]["revenue"]) for m in chart_months]
    chart_max = max(chart_revenue) if chart_revenue else 1

    html = template.render(
        stats=stats,
        recent=recent,
        chart_months=chart_months,
        chart_revenue=chart_revenue,
        chart_max=chart_max,
        format_inr=_format_inr,
        generated_at=datetime.now().strftime("%d %b %Y, %I:%M %p"),
    )

    with open(output_path, "w", encoding="utf-8") as f:
        f.write(html)


def _render_inline(stats, invoices, output_path):
    """Fallback renderer if Jinja2 isn't available — minimal HTML."""
    recent = sorted(
        invoices,
        key=lambda i: i.get("invoice_date") or i.get("date") or "",
        reverse=True,
    )[:10]

    rows = "\n".join(
        f"<tr><td>{i.get('invoice_number', '-')}</td><td>{i.get('customer_name', '-')}</td>"
        f"<td>{_format_inr(_to_decimal(i.get('grand_total', '0')))}</td>"
        f"<td>{i.get('tax_type', '-')}</td></tr>"
        for i in recent
    )

    gstr1_str = stats["gstr1_due"].strftime("%d %b %Y") if stats["gstr1_due"] else "—"

    html = f"""<!doctype html>
<html><head>
<meta charset="utf-8">
<title>GST Invoice Dashboard</title>
<style>
body {{ font-family: -apple-system, sans-serif; background: #F8FAFC; color: #0F172A; padding: 32px; max-width: 1200px; margin: 0 auto; }}
h1 {{ font-size: 28px; }}
.cards {{ display: grid; grid-template-columns: repeat(4, 1fr); gap: 16px; margin: 24px 0; }}
.card {{ background: #fff; padding: 20px; border-radius: 10px; border: 1px solid #E2E8F0; }}
.card .lbl {{ font-size: 11px; color: #64748B; text-transform: uppercase; font-weight: 700; letter-spacing: 0.5px; }}
.card .val {{ font-size: 24px; font-weight: 800; margin-top: 4px; }}
table {{ width: 100%; background: #fff; border-radius: 10px; overflow: hidden; border: 1px solid #E2E8F0; border-collapse: collapse; }}
th, td {{ padding: 10px 14px; text-align: left; border-bottom: 1px solid #F1F5F9; font-size: 13px; }}
th {{ background: #F8FAFC; font-weight: 700; color: #64748B; text-transform: uppercase; font-size: 11px; }}
</style>
</head><body>
<h1>⚡ GST Invoice Dashboard</h1>
<p>Generated {datetime.now().strftime("%d %b %Y, %I:%M %p")} · {stats["current_month_label"]}</p>
<div class="cards">
  <div class="card"><div class="lbl">Invoices Issued</div><div class="val">{stats["total_count"]}</div></div>
  <div class="card"><div class="lbl">This Month Revenue</div><div class="val">{_format_inr(stats["this_month_revenue"])}</div></div>
  <div class="card"><div class="lbl">GST Collected</div><div class="val">{_format_inr(stats["total_gst"])}</div></div>
  <div class="card"><div class="lbl">GSTR-1 Due</div><div class="val" style="font-size:18px;">{gstr1_str}</div></div>
</div>
<h2>Recent Invoices</h2>
<table><thead><tr><th>#</th><th>Customer</th><th>Total</th><th>Tax Type</th></tr></thead><tbody>{rows}</tbody></table>
</body></html>"""

    with open(output_path, "w", encoding="utf-8") as f:
        f.write(html)


def generate(ledger_path=None, output_path=None):
    """Public API: generate dashboard from ledger and write to output_path."""
    ledger_path = ledger_path or DEFAULT_LEDGER
    output_path = output_path or DEFAULT_OUTPUT

    invoices = load_invoices(ledger_path)
    stats = compute_stats(invoices)
    render_dashboard(stats, invoices, output_path)

    return {
        "dashboard_path": str(output_path),
        "invoices_count": stats["total_count"],
        "this_month_revenue": str(stats["this_month_revenue"]),
        "total_gst": str(stats["total_gst"]),
        "gstr1_due": stats["gstr1_due"].isoformat() if stats["gstr1_due"] else None,
    }


def main():
    p = argparse.ArgumentParser(description="Generate GST invoice dashboard from ledger")
    p.add_argument("--ledger", default=str(DEFAULT_LEDGER), help="Path to invoice_ledger.csv")
    p.add_argument("--out", default=str(DEFAULT_OUTPUT), help="Output dashboard.html path")
    args = p.parse_args()

    result = generate(args.ledger, args.out)
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
