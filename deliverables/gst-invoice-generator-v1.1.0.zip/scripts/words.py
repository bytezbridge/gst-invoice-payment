"""
Indian-numbering amount-in-words converter.
e.g. 123456.78 -> "One Lakh Twenty Three Thousand Four Hundred Fifty Six Rupees and Seventy Eight Paise Only"
"""

from decimal import Decimal


_ONES = [
    "", "One", "Two", "Three", "Four", "Five", "Six", "Seven", "Eight", "Nine",
    "Ten", "Eleven", "Twelve", "Thirteen", "Fourteen", "Fifteen",
    "Sixteen", "Seventeen", "Eighteen", "Nineteen"
]
_TENS = ["", "", "Twenty", "Thirty", "Forty", "Fifty", "Sixty", "Seventy", "Eighty", "Ninety"]


def _two_digits(n: int) -> str:
    if n < 20:
        return _ONES[n]
    return (_TENS[n // 10] + (" " + _ONES[n % 10] if n % 10 else "")).strip()


def _three_digits(n: int) -> str:
    out = ""
    if n >= 100:
        out += _ONES[n // 100] + " Hundred"
        n %= 100
        if n:
            out += " "
    if n:
        out += _two_digits(n)
    return out


def number_to_indian_words(num: int) -> str:
    """Convert a non-negative integer to Indian-numbering words."""
    if num == 0:
        return "Zero"

    parts = []
    crore = num // 10_000_000
    num %= 10_000_000
    lakh = num // 100_000
    num %= 100_000
    thousand = num // 1000
    num %= 1000
    hundred_etc = num

    if crore:
        parts.append(number_to_indian_words(crore) + " Crore")
    if lakh:
        parts.append(_two_digits(lakh) + " Lakh")
    if thousand:
        parts.append(_two_digits(thousand) + " Thousand")
    if hundred_etc:
        parts.append(_three_digits(hundred_etc))

    return " ".join(parts).strip()


def amount_to_words(amount) -> str:
    """Format a Decimal/float amount as 'X Rupees and Y Paise Only'."""
    amt = Decimal(str(amount))
    rupees = int(amt)
    paise = int((amt - rupees) * 100)

    text = number_to_indian_words(rupees) + " Rupees"
    if paise:
        text += " and " + number_to_indian_words(paise) + " Paise"
    text += " Only"
    return text


if __name__ == "__main__":
    samples = [Decimal("0"), Decimal("9"), Decimal("123"), Decimal("1234.56"),
               Decimal("123456.78"), Decimal("12345678.90")]
    for s in samples:
        print(f"{s:>15} -> {amount_to_words(s)}")
